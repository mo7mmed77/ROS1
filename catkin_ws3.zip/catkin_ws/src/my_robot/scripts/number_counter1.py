#!/usr/bin/env python 

import rospy
import math
import numpy
from std_msgs.msg import Int64
x=0
pub= None

def callback_number(msg):
    global x
    x += msg.data
    new_msg=Int64()
    new_msg.data=x
    pub.publish(new_msg)

        

if __name__=='__main__':
    rospy.init_node('number_counter1')

    sub = rospy.Subscriber("/number_publisher1",Int64,callback_number)

    pub=rospy.Publisher("/number_counter1",Int64,queue_size=10)

 #   rate=rospy.Rate(1)
  #  while not rospy.is_shutdown():
 #       msg=Int64()
 #       msg.data=x
  #      pub.publish(msg)
        #rate.sleep()

    rospy.spin()


